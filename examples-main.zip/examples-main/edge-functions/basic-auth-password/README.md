---
marketplace: false
---

# Basic Auth Password Protection

This example has been moved to [`edge-middleware`](/edge-middleware/basic-auth-password).

