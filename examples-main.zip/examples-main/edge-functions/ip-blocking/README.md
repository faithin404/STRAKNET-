---
marketplace: false
---

# IP Blocking with Upstash

This example has been moved to [`edge-middleware`](/edge-middleware/ip-blocking).
