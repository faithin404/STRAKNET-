---
marketplace: false
---

# Image Response Example

This example has been moved to [`edge-middleware`](/edge-middleware/image-response).
