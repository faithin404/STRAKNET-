---
marketplace: false
---

# Bot Detection with Botd

This example has been moved to [`edge-middleware`](/edge-middleware/bot-protection-botd).

