---
marketplace: false
---

# Next News

This example has been moved to [`starter`](/starter/next-news).
