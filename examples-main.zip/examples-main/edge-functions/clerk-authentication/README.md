---
marketplace: false
---

# Clerk Authentication at the edge

This example has been moved to [`edge-middleware`](/edge-middleware/clerk-authentication).
