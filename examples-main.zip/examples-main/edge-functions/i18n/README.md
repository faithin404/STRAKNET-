---
marketplace: false
---

# i18n

This example has been moved to [`edge-middleware`](/edge-middleware/i18n).
